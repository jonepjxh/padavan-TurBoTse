import ast, sys
p = r"C:\Users\Administrator\DoubaoWork\chats\2026-11-25\new-chat\router-debug\owl-build\owl_patch.py"
ast.parse(open(p, encoding="utf-8").read())
print("py syntax OK")
src = open(r"C:\Users\Administrator\DoubaoWork\chats\2026-11-25\new-chat\router-debug\owl\web_ex.c", encoding="utf-8", errors="ignore").read()
p1 = "static char SystemCmd[128] = {0};"
p2 = '\t\t\tdoSystem("%s >/tmp/syscmd.log 2>&1\\n", SystemCmd);'
print("p1 count", src.count(p1), "p2 count", src.count(p2))
