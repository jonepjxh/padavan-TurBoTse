#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
only-wl/padavan-4.4 (hanwckf 系) 补丁：
  1. 修复 IPv6：补 Advanced_IPv6_Content.asp 页面、默认值、切换后重载 NAT
  2. 加入插件中心：httpd 插件页面路由 + plugin_center() hook
所有替换均做命中数断言，避免静默错位。
"""
import os, re, sys

def read(p):
    with open(p, encoding="utf-8", errors="surrogateescape") as f:
        return f.read()

def write(p, s):
    with open(p, "w", encoding="utf-8", errors="surrogateescape", newline="\n") as f:
        f.write(s)

def sub1(path, pattern, repl, count=1, regex=False, label=""):
    s = read(path)
    if regex:
        m = re.search(pattern, s, re.M)
        n = 1 if m else 0
        assert n == count, f"[{label or path}] regex 未命中: {pattern!r}"
        s2 = re.sub(pattern, repl, s, count=count, flags=re.M)
    else:
        n = s.count(pattern)
        assert n == count, f"[{label or path}] 锚点命中 {n} 次(期望 {count}): {pattern!r}"
        s2 = s.replace(pattern, repl, count)
    write(path, s2)
    print(f"OK  {label or path}")

ROOT = os.getcwd()

# ---------------------------------------------------------------- 1. IPv6 默认值
DEF = "trunk/user/shared/defaults.c"
sub1(DEF, '{ "ip6_dns_auto", "0" },',  '{ "ip6_dns_auto", "1" },',  label="defaults: ip6_dns_auto")
# LAN 侧用固定 ULA：WAN 拿不到 PD 时也有内网 IPv6，拿到 PD 时可页面切到「自动前缀」
sub1(DEF, '{ "ip6_lan_addr", "" },',   '{ "ip6_lan_addr", "fc00:101:101::1" },', label="defaults: ip6_lan_addr")
# WAN 侧主动请求 DHCPv6 地址
sub1(DEF, '{ "ip6_wan_dhcp", "0" },',  '{ "ip6_wan_dhcp", "1" },',  label="defaults: ip6_wan_dhcp")

# ------------------------------------------------- 2. 启用 IPv6 后重载 NAT 模块
NET6 = "trunk/user/rc/net6.c"
s = read(NET6)
pat = re.compile(r"(\n\t*if \(!is_dns_dhcpd_run\(\)\)\n\t*start_dns_dhcpd\(0\);\n)(\t*\})")
assert len(pat.findall(s)) == 1, "net6.c: full_restart 锚点不唯一"
s = pat.sub(lambda m: m.group(1) + "\t\treload_nat_modules();\n" + m.group(2), s, count=1)
write(NET6, s)
print("OK  net6.c: 启用 IPv6 后 reload_nat_modules()")

# --------------------------------------------- 3. 模板打开 IPv6（B70 缺这一行）
for tpl in ("trunk/configs/templates/B70.config", "trunk/configs/templates/HC5962.config"):
    if not os.path.exists(tpl):
        print(f"SKIP {tpl} 不存在")
        continue
    s = read(tpl)
    if "CONFIG_FIRMWARE_ENABLE_IPV6" in s:
        print(f"OK  {tpl} 已含 IPv6 开关")
        continue
    anchor = "CONFIG_FIRMWARE_INCLUDE_SFE=y\n"
    assert s.count(anchor) == 1, f"{tpl}: SFE 锚点异常"
    s = s.replace(anchor, anchor + "\n### Enable IPv6 support\nCONFIG_FIRMWARE_ENABLE_IPV6=y\n", 1)
    write(tpl, s)
    print(f"OK  {tpl} 打开 CONFIG_FIRMWARE_ENABLE_IPV6=y")

# ------------------------------------------------------------ 4. httpd 插件路由
HTTPD = "trunk/user/httpd/httpd.c"
sub1(HTTPD,
     "\tint len, login_state, method_id, do_logout, clen = 0;",
     "\tint len, login_state, method_id, do_logout, clen = 0;\n\tint is_plugin_file = 0;",
     label="httpd: is_plugin_file 声明")

PLUGIN_FN = r'''
/* ------------------------------------------------------------------------
 * plugincenter: 插件 Web 页面映射
 *   /plugin/<pkg>/<file>  ->  /etc/storage/plugins/<pkg>/web/<file>
 * 插件目录名白名单 [A-Za-z0-9._-]，拒绝纯点、反斜杠与 ".."，防止路径穿越。
 * ------------------------------------------------------------------------ */
#define PLUGIN_URL_PREFIX	"plugin/"
#define PLUGIN_STORE_DIR	"/etc/storage/plugins"
#define PLUGIN_WEB_SUBDIR	"web"
#define PLUGIN_PKG_NAME_MAX	64
#define PLUGIN_PATH_MAX		512

static char *
plugin_web_path(const char *url)
{
	static char path[PLUGIN_PATH_MAX];
	const char *pkg, *pkg_end, *rest, *s;
	char *d;
	int all_dot;

	if (strncmp(url, PLUGIN_URL_PREFIX, sizeof(PLUGIN_URL_PREFIX) - 1) != 0)
		return NULL;

	pkg = url + sizeof(PLUGIN_URL_PREFIX) - 1;
	pkg_end = strchr(pkg, '/');
	if (!pkg_end || pkg_end == pkg || *(pkg_end + 1) == '\0')
		return NULL;
	if ((size_t) (pkg_end - pkg) > PLUGIN_PKG_NAME_MAX)
		return NULL;

	all_dot = 1;
	for (s = pkg; s < pkg_end; s++) {
		unsigned char c = (unsigned char) *s;

		if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') ||
		      (c >= 'A' && c <= 'Z') || c == '_' || c == '-' || c == '.'))
			return NULL;
		if (c != '.')
			all_dot = 0;
	}
	if (all_dot)
		return NULL;

	rest = pkg_end + 1;
	for (s = rest; ; s++) {
		if (*s == '\\')
			return NULL;
		if (s[0] == '.' && s[1] == '.' &&
		    (s == rest || s[-1] == '/') && (s[2] == '/' || s[2] == '\0'))
			return NULL;
		if (*s == '\0')
			break;
	}

	if (strlen(PLUGIN_STORE_DIR) + (size_t) (pkg_end - pkg) +
	    sizeof(PLUGIN_WEB_SUBDIR) + strlen(rest) + 4 > sizeof(path))
		return NULL;

	d = path;
	strcpy(d, PLUGIN_STORE_DIR);
	d += strlen(PLUGIN_STORE_DIR);
	*d++ = '/';
	memcpy(d, pkg, (size_t) (pkg_end - pkg));
	d += (pkg_end - pkg);
	*d++ = '/';
	memcpy(d, PLUGIN_WEB_SUBDIR, sizeof(PLUGIN_WEB_SUBDIR) - 1);
	d += sizeof(PLUGIN_WEB_SUBDIR) - 1;
	*d++ = '/';
	strcpy(d, rest);

	return path;
}

static void
handle_request(FILE *conn_fp, const conn_item_t *item)'''
sub1(HTTPD, "\nstatic void\nhandle_request(FILE *conn_fp, const conn_item_t *item)",
     "\n" + PLUGIN_FN, label="httpd: plugin_web_path 函数")

sub1(HTTPD,
     "\tquery = file;\n\tstrsep(&query, \"?\");\n",
     "\tquery = file;\n\tstrsep(&query, \"?\");\n\n"
     "\t/* plugincenter: 插件自带页面走 /plugin/<pkg>/<file> */\n"
     "\t{\n"
     "\t\tchar *plugin_path = plugin_web_path(file);\n"
     "\t\tif (plugin_path != NULL) {\n"
     "\t\t\tfile = plugin_path;\n"
     "\t\t\tis_plugin_file = 1;\n"
     "\t\t}\n"
     "\t}\n",
     label="httpd: 插件页面路由")

sub1(HTTPD,
     "\tif (!handler->pattern) {\n"
     "\t\tsend_error( 404, \"Not Found\", NULL, \"URL was not found.\", conn_fp );\n"
     "\t\treturn;\n"
     "\t}\n",
     "\tif (!handler->pattern) {\n"
     "\t\tsend_error( 404, \"Not Found\", NULL, \"URL was not found.\", conn_fp );\n"
     "\t\treturn;\n"
     "\t}\n\n"
     "\t/* 插件页面不在只读 /www 里，do_ej 按相对路径会读不到，改为静态输出 */\n"
     "\tif (is_plugin_file && handler->output == do_ej)\n"
     "\t\thandler->output = do_file;\n",
     label="httpd: 插件页面静态输出")

# --------------------------------------------------------- 5. web_ex.c 插件 hook
WEBEX = "trunk/user/httpd/web_ex.c"
PLUGIN_HOOK = r'''/* plugincenter: 把插件状态文件输出成 JS 数组，供 Advanced_plugincenter.asp 使用 */
static int ej_plugin_center_hook(int eid, webs_t wp, int argc, char **argv)
{
	const char *path = "/etc/storage/plugins/.view.txt";
	FILE *fp;
	char buf[1024];
	char *q;
	int first = 1;

	fputs("[", wp);
	fp = fopen(path, "r");
	if (fp) {
		while (fgets(buf, sizeof(buf), fp) != NULL) {
			buf[strcspn(buf, "\r\n")] = 0;
			if (!buf[0]) continue;
			if (!first) fputs(",", wp);
			fputs("\"", wp);
			for (q = buf; *q; ++q) {
				if (*q == '"' || *q == '\\') fputs("\\", wp);
				fputc(*q, wp);
			}
			fputs("\"", wp);
			first = 0;
		}
		fclose(fp);
	}
	fputs("]", wp);
	fflush(wp);
	return 0;
}

'''
sub1(WEBEX, "static int ej_dump_syslog_hook(int eid, webs_t wp, int argc, char **argv)",
     PLUGIN_HOOK + "static int ej_dump_syslog_hook(int eid, webs_t wp, int argc, char **argv)",
     label="web_ex.c: ej_plugin_center_hook")

sub1(WEBEX, '\t{ "openvpn_cli_cert_hook", openvpn_cli_cert_hook},',
     '\t{ "openvpn_cli_cert_hook", openvpn_cli_cert_hook},\n\t{ "plugin_center", ej_plugin_center_hook},',
     label="web_ex.c: hook 注册")

# --------------------------------------------- 6. pluginctl 安装到 /usr/bin
sub1("trunk/user/scripts/Makefile",
     "\t$(ROMFSINST) /sbin/check_crontab.sh\n",
     "\t$(ROMFSINST) /sbin/check_crontab.sh\n\t$(ROMFSINST) -p +x $(THISDIR)/pluginctl /usr/bin/pluginctl\n",
     label="scripts/Makefile: 安装 pluginctl")

# --------------------------------------------------------- 7. 中文词条
DICT = "trunk/user/www/dict/CN.dict"
s = read(DICT)
if "menu5_40=" in s:
    print("OK  CN.dict 已含 menu5_40")
else:
    s = s.rstrip("\n") + "\nmenu5_40=插件中心\n"
    write(DICT, s)
    print("OK  CN.dict 追加 menu5_40=插件中心")

print("ALL PATCHES APPLIED")
