#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
only-wl/padavan-4.4 (hanwckf 系) 补丁：
  1. 修复 IPv6：补 Advanced_IPv6_Content.asp 页面、默认值、切换后重载 NAT
  2. 加入插件中心：httpd 插件页面路由 + plugin_center() hook
所有替换均做命中数断言，避免静默错位。
"""
import os, re, sys

def read(p):
    with open(p, encoding="utf-8", errors="surrogateescape") as f:
        return f.read()

def write(p, s):
    with open(p, "w", encoding="utf-8", errors="surrogateescape", newline="\n") as f:
        f.write(s)

def sub1(path, pattern, repl, count=1, regex=False, label=""):
    s = read(path)
    if regex:
        m = re.search(pattern, s, re.M)
        n = 1 if m else 0
        assert n == count, f"[{label or path}] regex 未命中: {pattern!r}"
        s2 = re.sub(pattern, repl, s, count=count, flags=re.M)
    else:
        n = s.count(pattern)
        assert n == count, f"[{label or path}] 锚点命中 {n} 次(期望 {count}): {pattern!r}"
        s2 = s.replace(pattern, repl, count)
    write(path, s2)
    print(f"OK  {label or path}")

ROOT = os.getcwd()

# ---------------------------------------------------------------- 1. IPv6 默认值
DEF = "trunk/user/shared/defaults.c"
sub1(DEF, '{ "ip6_dns_auto", "0" },',  '{ "ip6_dns_auto", "1" },',  label="defaults: ip6_dns_auto")
# LAN 侧用固定 ULA：WAN 拿不到 PD 时也有内网 IPv6，拿到 PD 时可页面切到「自动前缀」
sub1(DEF, '{ "ip6_lan_addr", "" },',   '{ "ip6_lan_addr", "fc00:101:101::1" },', label="defaults: ip6_lan_addr")
# WAN 侧主动请求 DHCPv6 地址
sub1(DEF, '{ "ip6_wan_dhcp", "0" },',  '{ "ip6_wan_dhcp", "1" },',  label="defaults: ip6_wan_dhcp")

# ------------------------------------------------- 2. 启用 IPv6 后重载 NAT 模块
NET6 = "trunk/user/rc/net6.c"
s = read(NET6)
pat = re.compile(r"(\n\t*if \(!is_dns_dhcpd_run\(\)\)\n\t*start_dns_dhcpd\(0\);\n)(\t*\})")
assert len(pat.findall(s)) == 1, "net6.c: full_restart 锚点不唯一"
s = pat.sub(lambda m: m.group(1) + "\t\treload_nat_modules();\n" + m.group(2), s, count=1)
write(NET6, s)
print("OK  net6.c: 启用 IPv6 后 reload_nat_modules()")

# --------------------------------------------- 3. 模板打开 IPv6（B70 缺这一行）
for tpl in ("trunk/configs/templates/B70.config", "trunk/configs/templates/HC5962.config"):
    if not os.path.exists(tpl):
        print(f"SKIP {tpl} 不存在")
        continue
    s = read(tpl)
    if "CONFIG_FIRMWARE_ENABLE_IPV6" in s:
        print(f"OK  {tpl} 已含 IPv6 开关")
        continue
    anchor = "CONFIG_FIRMWARE_INCLUDE_SFE=y\n"
    assert s.count(anchor) == 1, f"{tpl}: SFE 锚点异常"
    s = s.replace(anchor, anchor + "\n### Enable IPv6 support\nCONFIG_FIRMWARE_ENABLE_IPV6=y\n", 1)
    write(tpl, s)
    print(f"OK  {tpl} 打开 CONFIG_FIRMWARE_ENABLE_IPV6=y")

# ------------------------------------------------------------ 4. httpd 插件路由
HTTPD = "trunk/user/httpd/httpd.c"
sub1(HTTPD,
     "\tint len, login_state, method_id, do_logout, clen = 0;",
     "\tint len, login_state, method_id, do_logout, clen = 0;\n\tint is_plugin_file = 0;",
     label="httpd: is_plugin_file 声明")

PLUGIN_FN = r'''
/* ------------------------------------------------------------------------
 * plugincenter: 插件 Web 页面映射
 *   /plugin/<pkg>/<file>  ->  /etc/storage/plugins/<pkg>/web/<file>
 * 插件目录名白名单 [A-Za-z0-9._-]，拒绝纯点、反斜杠与 ".."，防止路径穿越。
 * ------------------------------------------------------------------------ */
#define PLUGIN_URL_PREFIX	"plugin/"
#define PLUGIN_STORE_DIR	"/etc/storage/plugins"
#define PLUGIN_WEB_SUBDIR	"web"
#define PLUGIN_PKG_NAME_MAX	64
#define PLUGIN_PATH_MAX		512

static char *
plugin_web_path(const char *url)
{
	static char path[PLUGIN_PATH_MAX];
	const char *pkg, *pkg_end, *rest, *s;
	char *d;
	int all_dot;

	if (strncmp(url, PLUGIN_URL_PREFIX, sizeof(PLUGIN_URL_PREFIX) - 1) != 0)
		return NULL;

	pkg = url + sizeof(PLUGIN_URL_PREFIX) - 1;
	pkg_end = strchr(pkg, '/');
	if (!pkg_end || pkg_end == pkg || *(pkg_end + 1) == '\0')
		return NULL;
	if ((size_t) (pkg_end - pkg) > PLUGIN_PKG_NAME_MAX)
		return NULL;

	all_dot = 1;
	for (s = pkg; s < pkg_end; s++) {
		unsigned char c = (unsigned char) *s;

		if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') ||
		      (c >= 'A' && c <= 'Z') || c == '_' || c == '-' || c == '.'))
			return NULL;
		if (c != '.')
			all_dot = 0;
	}
	if (all_dot)
		return NULL;

	rest = pkg_end + 1;
	for (s = rest; ; s++) {
		if (*s == '\\')
			return NULL;
		if (s[0] == '.' && s[1] == '.' &&
		    (s == rest || s[-1] == '/') && (s[2] == '/' || s[2] == '\0'))
			return NULL;
		if (*s == '\0')
			break;
	}

	if (strlen(PLUGIN_STORE_DIR) + (size_t) (pkg_end - pkg) +
	    sizeof(PLUGIN_WEB_SUBDIR) + strlen(rest) + 4 > sizeof(path))
		return NULL;

	d = path;
	strcpy(d, PLUGIN_STORE_DIR);
	d += strlen(PLUGIN_STORE_DIR);
	*d++ = '/';
	memcpy(d, pkg, (size_t) (pkg_end - pkg));
	d += (pkg_end - pkg);
	*d++ = '/';
	memcpy(d, PLUGIN_WEB_SUBDIR, sizeof(PLUGIN_WEB_SUBDIR) - 1);
	d += sizeof(PLUGIN_WEB_SUBDIR) - 1;
	*d++ = '/';
	strcpy(d, rest);

	return path;
}

static void
handle_request(FILE *conn_fp, const conn_item_t *item)'''
sub1(HTTPD, "\nstatic void\nhandle_request(FILE *conn_fp, const conn_item_t *item)",
     "\n" + PLUGIN_FN, label="httpd: plugin_web_path 函数")

sub1(HTTPD,
     "\tquery = file;\n\tstrsep(&query, \"?\");\n",
     "\tquery = file;\n\tstrsep(&query, \"?\");\n\n"
     "\t/* plugincenter: 插件自带页面走 /plugin/<pkg>/<file> */\n"
     "\t{\n"
     "\t\tchar *plugin_path = plugin_web_path(file);\n"
     "\t\tif (plugin_path != NULL) {\n"
     "\t\t\tfile = plugin_path;\n"
     "\t\t\tis_plugin_file = 1;\n"
     "\t\t}\n"
     "\t}\n",
     label="httpd: 插件页面路由")

sub1(HTTPD,
     "\tif (!handler->pattern) {\n"
     "\t\tsend_error( 404, \"Not Found\", NULL, \"URL was not found.\", conn_fp );\n"
     "\t\treturn;\n"
     "\t}\n",
     "\tif (!handler->pattern) {\n"
     "\t\tsend_error( 404, \"Not Found\", NULL, \"URL was not found.\", conn_fp );\n"
     "\t\treturn;\n"
     "\t}\n\n"
     "\t/* 插件页面不在只读 /www 里，do_ej 按相对路径会读不到，改为静态输出 */\n"
     "\tif (is_plugin_file && handler->output == do_ej)\n"
     "\t\thandler->output = do_file;\n",
     label="httpd: 插件页面静态输出")

# --------------------------------------------------------- 5. web_ex.c 插件 hook
WEBEX = "trunk/user/httpd/web_ex.c"
PLUGIN_HOOK = r'''/* plugincenter: 把插件状态文件输出成 JS 数组，供 Advanced_plugincenter.asp 使用 */
static int ej_plugin_center_hook(int eid, webs_t wp, int argc, char **argv)
{
	const char *path = "/etc/storage/plugins/.view.txt";
	FILE *fp;
	char buf[1024];
	char *q;
	int first = 1;

	fputs("[", wp);
	fp = fopen(path, "r");
	if (fp) {
		while (fgets(buf, sizeof(buf), fp) != NULL) {
			buf[strcspn(buf, "\r\n")] = 0;
			if (!buf[0]) continue;
			if (!first) fputs(",", wp);
			fputs("\"", wp);
			for (q = buf; *q; ++q) {
				if (*q == '"' || *q == '\\') fputs("\\", wp);
				fputc(*q, wp);
			}
			fputs("\"", wp);
			first = 0;
		}
		fclose(fp);
	}
	fputs("]", wp);
	fflush(wp);
	return 0;
}

'''
sub1(WEBEX, "static int ej_dump_syslog_hook(int eid, webs_t wp, int argc, char **argv)",
     PLUGIN_HOOK + "static int ej_dump_syslog_hook(int eid, webs_t wp, int argc, char **argv)",
     label="web_ex.c: ej_plugin_center_hook")

sub1(WEBEX, '\t{ "openvpn_cli_cert_hook", openvpn_cli_cert_hook},',
     '\t{ "openvpn_cli_cert_hook", openvpn_cli_cert_hook},\n\t{ "plugin_center", ej_plugin_center_hook},',
     label="web_ex.c: hook 注册")

# --------------------------------------------- 6. pluginctl 安装到 /usr/bin
sub1("trunk/user/scripts/Makefile",
     "\t$(ROMFSINST) /sbin/check_crontab.sh\n",
     "\t$(ROMFSINST) /sbin/check_crontab.sh\n\t$(ROMFSINST) -p +x $(THISDIR)/pluginctl /usr/bin/pluginctl\n",
     label="scripts/Makefile: 安装 pluginctl")

# --------------------------------------------------------- 7. 中文词条
DICT = "trunk/user/www/dict/CN.dict"
s = read(DICT)
if "menu5_40=" in s:
    print("OK  CN.dict 已含 menu5_40")
else:
    s = s.rstrip("\n") + "\nmenu5_40=插件中心\n"
    write(DICT, s)
    print("OK  CN.dict 追加 menu5_40=插件中心")

# --------------------------------------- 8. 主菜单：删穿透服务(空槽位，由动态菜单接管)
STATE = "trunk/user/www/n56u_ribbon_fixed/state.js"
s = read(STATE)
assert "menu5_30" not in s, "state.js 仍含穿透服务菜单"
assert "Advanced_wireguard.asp" not in s, "state.js 仍挂 wireguard 页面"
assert "Advanced_plugincenter.asp" not in s, "插件中心应由 httpd 动态注入，不应静态写死"
print("OK  state.js: 穿透服务已移除(空槽位)，插件中心交给动态菜单")

# ------------------------------- 9. 插件中心运行时：菜单注入 + 详情/设置钩子
# 9a 编译单元
sub1("trunk/user/httpd/Makefile",
     "OBJS = httpd.o ej.o cgi.o web_ex.o common.o nvram_x.o ralink.o crc32.o base64.o aspbw.o initial_web_hook.o variables.o",
     "OBJS = httpd.o ej.o cgi.o web_ex.o plugin_center.o common.o nvram_x.o ralink.o crc32.o base64.o aspbw.o initial_web_hook.o variables.o",
     label="httpd/Makefile: 加入 plugin_center.o")

# 9b state.js 输出后追加插件菜单（**.js 走 do_js 而不是裸 do_ej）
sub1("trunk/user/httpd/web_ex.c",
     '\t{ "**.js",  "text/javascript", no_cache_IE, NULL, do_ej, 1 },',
     '\t{ "**.js",  "text/javascript", no_cache_IE, NULL, do_js, 1 },',
     label="web_ex.c: **.js -> do_js")

# 9c 外部符号声明（plugin_center.c 导出）
sub1("trunk/user/httpd/web_ex.c",
     "static char SystemCmd[128] = {0};",
     "extern void do_js(const char *url, FILE *stream);\n"
     "extern int ej_plugin_detail_hook(int eid, webs_t wp, int argc, char **argv);\n"
     "extern int ej_plugin_webui_hook(int eid, webs_t wp, int argc, char **argv);\n\n"
     "static char SystemCmd[128] = {0};",
     label="web_ex.c: extern 声明")

# 9d 注册详情/设置钩子
sub1("trunk/user/httpd/web_ex.c",
     '\t{ "plugin_center", ej_plugin_center_hook},',
     '\t{ "plugin_center", ej_plugin_center_hook},\n'
     '\t{ "plugin_detail", ej_plugin_detail_hook},\n'
     '\t{ "plugin_webui", ej_plugin_webui_hook},',
     label="web_ex.c: 注册 plugin_detail / plugin_webui")

# 9e SystemCmd 链路：原版 SystemCmd[128] + doSystem 的 512 字节栈缓冲，插件中心一次
#    提交多字段配置（如 ssrplus）会被截断，表现为「点保存没反应/只执行一半」。
#    1) 缓冲区放到 4096；2) 命令不再拼进 doSystem，而是落盘成 /tmp/syscmdcmd.sh 再执行，
#       彻底摆脱 512 字节限制，同时保留 /tmp/syscmd.log 语义。
sub1("trunk/user/httpd/web_ex.c",
     "static char SystemCmd[128] = {0};",
     "static char SystemCmd[4096] = {0};",
     label="web_ex.c: SystemCmd 缓冲 128 -> 4096")

sub1("trunk/user/httpd/web_ex.c",
     "\t\t\tdoSystem(\"%s >/tmp/syscmd.log 2>&1\\n\", SystemCmd);",
     "\t\t\t{\n"
     "\t\t\t\tFILE *fcmd = fopen(\"/tmp/syscmdcmd.sh\", \"w\");\n"
     "\t\t\t\tif (fcmd) {\n"
     "\t\t\t\t\tfputs(\"#!/bin/sh\\n\", fcmd);\n"
     "\t\t\t\t\tfputs(SystemCmd, fcmd);\n"
     "\t\t\t\t\tfputs(\"\\n\", fcmd);\n"
     "\t\t\t\t\tfclose(fcmd);\n"
     "\t\t\t\t}\n"
     "\t\t\t\tdoSystem(\"sh /tmp/syscmdcmd.sh >/tmp/syscmd.log 2>&1\\n\");\n"
     "\t\t\t}",
     label="web_ex.c: SystemCmd 落盘执行（绕开 512 字节）")

assert os.path.exists("trunk/user/httpd/plugin_center.c"), "plugin_center.c 未随 overlay 落地"
s = read("trunk/user/httpd/plugin_center.c")
assert "plugin_menu_emit" in s and "ej_plugin_webui_hook" in s
print("OK  plugin_center.c: %d bytes" % len(s))

# ------------------------------- 10. musl 运行库：让插件仓库里的 musl 插件能跑
# 本树用 uClibc 工具链，而插件仓库（jonepjxh/padavan-TurBoTse release: plugin-repo）
# 的二进制是 mipsel-linux-musl 编译的，interp 为 /lib/ld-musl-mipsel.so.1。
# 不补这一层，插件 start.sh 里执行 /opt/bin/<bin> 会报 "not found"。
MUSL_FILES = [
    ("ld-musl-mipsel.so.1", "ld-musl-mipsel.so.1"),
    ("libc.so", "libc.so"),
    ("libssl.so.3", "libssl.so.3"),
    ("libcrypto.so.3", "libcrypto.so.3"),
]
for src, _ in MUSL_FILES:
    assert os.path.exists("owl-musl/" + src), "owl-musl/%s 未随 overlay 落地" % src

musl_rec = "".join(
    "\tcp -f $(ROOTDIR)/../owl-musl/{0} $(ROMFSDIR)/lib/{1}\n".format(a, b)
    for a, b in MUSL_FILES
)
sub1("trunk/Makefile",
     "romfs.post:\n\t-find $(ROMFSDIR)/. -name CVS | xargs -r rm -rf ; \\",
     "romfs.post:\n"
     "\t@mkdir -p $(ROMFSDIR)/lib\n" + musl_rec +
     "\t@chmod 755 $(ROMFSDIR)/lib/ld-musl-mipsel.so.1 $(ROMFSDIR)/lib/libc.so"
     " $(ROMFSDIR)/lib/libssl.so.3 $(ROMFSDIR)/lib/libcrypto.so.3\n"
     "\t@test -s $(ROMFSDIR)/lib/ld-musl-mipsel.so.1 || { echo 'owl: musl 库未复制到 romfs'; exit 1; }\n"
     "\t-find $(ROMFSDIR)/. -name CVS | xargs -r rm -rf ; \\",
     label="trunk/Makefile: romfs 里补 musl 运行库")

print("ALL PATCHES APPLIED")
