import io, sys, os

P = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'state.js')
s = io.open(P, encoding='utf-8', newline='').read()

def rep(old, new, label):
    global s
    n = s.count(old)
    assert n == 1, "%s: expected 1 hit, got %d" % (label, n)
    s = s.replace(old, new, 1)
    print("  ok  %s" % label)

# 1) Level-3 tab title: 穿透服务 -> 插件中心
rep(
'if (found_app_aliddns()||found_app_zerotier()||found_app_ddnsto()||found_app_wireguard()){\n\ttabtitle[16] = new Array("", "<#menu5_30#>");\n}',
'tabtitle[16] = new Array("", "插件中心");',
'L3 title 16 -> 插件中心')

# 2) Level-3 tab link: 整条 穿透服务 链 -> 插件中心页面
rep(
'''if (found_app_aliddns()){
	aliddns_array = new Array("","Advanced_aliddns.asp");
	tablink[16] = (aliddns_array);
}else if (found_app_zerotier()){
	zerotier_array = new Array("","Advanced_zerotier.asp");
	tablink[16] = (zerotier_array);
}else if (found_app_ddnsto()){
	ddnsto_array = new Array("","Advanced_ddnsto.asp");
	tablink[16] = (ddnsto_array);
}else if (found_app_wireguard()){
	wireguard_array = new Array("","Advanced_wireguard.asp");
	tablink[16] = (wireguard_array);
}''',
'tablink[16] = new Array("", "Advanced_plugincenter.asp");',
'L3 link 16 -> plugincenter')

# 3) Level-2 menu title
rep(
'if (found_app_aliddns()||found_app_zerotier()||found_app_ddnsto()||found_app_wireguard()){\n\tmenuL2_title.push("<#menu5_30#>");\n} else menuL2_title.push("");',
'menuL2_title.push("插件中心");',
'L2 title -> 插件中心')

# 4) Level-2 menu link
rep(
'''if (found_app_aliddns()){
	menuL2_link.push(aliddns_array[1]);
} else if (found_app_zerotier()){
	menuL2_link.push(zerotier_array[1]);
} else if (found_app_ddnsto()){
	menuL2_link.push(ddnsto_array[1]);
} else if (found_app_wireguard()){
	menuL2_link.push(wireguard_array[1]);
} else menuL2_link.push("");''',
'menuL2_link.push("Advanced_plugincenter.asp");',
'L2 link -> plugincenter')

# sanity
assert 'Advanced_plugincenter.asp' in s, "plugincenter link missing"
assert '<#menu5_30#>' not in s, "穿透服务 title still present"
assert 'Advanced_wireguard.asp' not in s, "wireguard still wired"
assert 'found_app_wireguard' not in s, "wireguard finder still wired"

io.open(P, 'w', encoding='utf-8', newline='').write(s)
print("state.js patched, %d bytes" % len(s.encode('utf-8')))
