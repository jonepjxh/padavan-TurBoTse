# -*- coding: utf-8 -*-
"""从 only-wl 原始 state.js 生成 overlay 版本：
   删除「穿透服务」(wireguard / aliddns / zerotier / ddnsto) 静态菜单，
   保留空槽位以维持 menuL2 与 tabtitle/tablink 的索引对齐。
   插件中心不再静态写死，由 httpd 在 /state.js 末尾追加的 plugin_menu_emit 生成。"""
import io, os, sys

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'state_orig.js')
DST = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   'trunk', 'user', 'www', 'n56u_ribbon_fixed', 'state.js')

s = io.open(SRC, encoding='utf-8', newline='').read()

def rep(old, new, label):
    global s
    n = s.count(old)
    assert n == 1, "%s: 命中 %d 次(期望1)" % (label, n)
    s = s.replace(old, new, 1)
    print("  ok  " + label)

# 1) L3 tab title：整段删掉穿透服务
rep(
'if (found_app_aliddns()||found_app_zerotier()||found_app_ddnsto()||found_app_wireguard()){\n\ttabtitle[16] = new Array("", "<#menu5_30#>");\n}\n',
'',
'L3 title 16 removed')

# 2) L3 tab link：整条链删掉
rep(
'''if (found_app_aliddns()){
	aliddns_array = new Array("","Advanced_aliddns.asp");
	tablink[16] = (aliddns_array);
}else if (found_app_zerotier()){
	zerotier_array = new Array("","Advanced_zerotier.asp");
	tablink[16] = (zerotier_array);
}else if (found_app_ddnsto()){
	ddnsto_array = new Array("","Advanced_ddnsto.asp");
	tablink[16] = (ddnsto_array);
}else if (found_app_wireguard()){
	wireguard_array = new Array("","Advanced_wireguard.asp");
	tablink[16] = (wireguard_array);
}
''',
'',
'L3 link 16 removed')

# 3) L2 菜单标题：留空占位
rep(
'if (found_app_aliddns()||found_app_zerotier()||found_app_ddnsto()||found_app_wireguard()){\n\tmenuL2_title.push("<#menu5_30#>");\n} else menuL2_title.push("");',
'menuL2_title.push("");',
'L2 title slot blank')

# 4) L2 菜单链接：留空占位
rep(
'''if (found_app_aliddns()){
	menuL2_link.push(aliddns_array[1]);
} else if (found_app_zerotier()){
	menuL2_link.push(zerotier_array[1]);
} else if (found_app_ddnsto()){
	menuL2_link.push(ddnsto_array[1]);
} else if (found_app_wireguard()){
	menuL2_link.push(wireguard_array[1]);
} else menuL2_link.push("");''',
'menuL2_link.push("");',
'L2 link slot blank')

assert 'menu5_30' not in s, '穿透服务菜单仍在'
assert 'Advanced_wireguard.asp' not in s, 'wireguard 页面仍挂菜单'
assert 'Advanced_plugincenter.asp' not in s, '插件中心静态项应移除(由 httpd 动态注入)'
assert s.count('menuL2_title.push("")') >= 1
io.open(DST, 'w', encoding='utf-8', newline='').write(s)
print("state.js written: %d bytes" % len(s.encode('utf-8')))
