#!/bin/sh
# 3proxy - started by the plugin center (pluginctl)
B=/etc/storage/plugins/3proxy
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
CFG=$B/3proxy.cfg
[ -s "$CFG" ] || printf 'proxy -p3128\n' > "$CFG"
cd "$B" || exit 1
/opt/bin/3proxy "$CFG" >/tmp/3proxy.log 2>&1 &
echo $! > "$P"
