#!/bin/sh
# adguardhome - started by the plugin center (pluginctl)
B=/etc/storage/plugins/adguardhome
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
W=$B/work
mkdir -p "$W"
if [ ! -f "$W/AdGuardHome.yaml" ]; then
	cat > "$W/AdGuardHome.yaml" <<EOF
bind_host: 0.0.0.0
bind_port: $(v agd_port 3000)
dns:
  bind_hosts:
    - 0.0.0.0
  port: $(v agd_dns_port 5353)
  upstream_dns:
$(for s in $(v agd_upstream "223.5.5.5"); do echo "    - $s"; done)
EOF
fi
/opt/bin/AdGuardHome -c "$W/AdGuardHome.yaml" -w "$W" --no-check-update >/tmp/adguardhome.log 2>&1 &
echo $! > "$P"
