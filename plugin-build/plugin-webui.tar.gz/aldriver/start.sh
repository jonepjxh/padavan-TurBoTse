#!/bin/sh
# aldriver - started by the plugin center (pluginctl)
B=/etc/storage/plugins/aldriver
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/aliyundrive-webdav --refresh-token "$(v ald_refresh_token "")" \
	--port $(v ald_port 8080) \
	--auth-user "$(v ald_auth_user admin)" \
	--auth-password "$(v ald_auth_pass "")" \
	--root "$(v ald_root /)" >/tmp/aliyundrive.log 2>&1 &
echo $! > "$P"
