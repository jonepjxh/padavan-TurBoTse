#!/bin/sh
# aliddns - started by the plugin center (pluginctl)
B=/etc/storage/plugins/aliddns
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
while IFS='=' read -r k val; do
	case "$k" in ''|\#*) continue;; esac
	nvram set "$k=$val" 2>/dev/null
done < "$C"
nvram set aliddns_enable=1 2>/dev/null
LOOP="while true; do /opt/bin/aliddns.sh >/tmp/aliddns.log 2>&1; sleep $(v aliddns_interval 300); done"
sh -c "$LOOP" &
echo $! > "$P"
