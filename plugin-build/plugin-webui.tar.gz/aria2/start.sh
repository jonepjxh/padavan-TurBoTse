#!/bin/sh
# aria2 - started by the plugin center (pluginctl)
B=/etc/storage/plugins/aria2
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
DIR=$(v aria_dir /media/AiDisk_a1/download)
mkdir -p "$DIR" 2>/dev/null
CONF=$B/aria2.conf
cat > "$CONF" <<EOF
enable-rpc=true
rpc-listen-all=true
rpc-allow-origin-all=true
rpc-listen-port=$(v aria_port 6800)
rpc-secret=$(v aria_token padavan)
dir=$DIR
continue=true
max-concurrent-downloads=$(v aria_max 3)
input-file=$B/session.txt
save-session=$B/session.txt
EOF
/opt/bin/aria2c --conf-path="$CONF" -D >/tmp/aria2.log 2>&1
sleep 1
pidof aria2c > "$P"
