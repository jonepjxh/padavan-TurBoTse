#!/bin/sh
# chinadns_ng - started by the plugin center (pluginctl)
B=/etc/storage/plugins/chinadns_ng
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/chinadns-ng -b 0.0.0.0 -l $(v cdns_port 65353) \
	-c "$(v cdns_cn_dns 223.5.5.5:53)" -t "$(v cdns_trust_dns 8.8.8.8:53)" \
	>/tmp/chinadns.log 2>&1 &
echo $! > "$P"
