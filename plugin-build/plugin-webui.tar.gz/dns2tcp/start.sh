#!/bin/sh
# dns2tcp - started by the plugin center (pluginctl)
B=/etc/storage/plugins/dns2tcp
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/dns2tcp -L "$(v d2t_listen 127.0.0.1:5353)" -R "$(v d2t_remote 8.8.8.8:53)" \
	>/tmp/dns2tcp.log 2>&1 &
echo $! > "$P"
