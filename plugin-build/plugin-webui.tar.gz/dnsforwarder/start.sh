#!/bin/sh
# dnsforwarder - started by the plugin center (pluginctl)
B=/etc/storage/plugins/dnsforwarder
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/dns-forwarder -b $(v df_bind 0.0.0.0) -p $(v df_port 5300) -s "$(v df_server 223.5.5.5)" >/tmp/dnsforwarder.log 2>&1 &
echo $! > "$P"
