#!/bin/sh
# dnsmasq - started by the plugin center (pluginctl)
B=/etc/storage/plugins/dnsmasq
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
PORT=$(v dnsm_port 6053)
CONF=/tmp/dnsmasq-plugin.conf
: > "$CONF"
echo "port=$PORT" >> "$CONF"
echo "cache-size=$(v dnsm_cache 1500)" >> "$CONF"
echo "no-resolv" >> "$CONF"
echo "no-hosts" >> "$CONF"
echo "bind-dynamic" >> "$CONF"
[ "$(v dnsm_log 0)" = "1" ] && echo "log-queries" >> "$CONF"
for s in $(v dnsm_upstream "223.5.5.5 119.29.29.29"); do echo "server=$s" >> "$CONF"; done
/opt/sbin/dnsmasq -C "$CONF" -x "$P" >/tmp/dnsmasq-plugin.log 2>&1 &
sleep 1
