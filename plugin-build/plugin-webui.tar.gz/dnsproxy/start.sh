#!/bin/sh
# dnsproxy - started by the plugin center (pluginctl)
B=/etc/storage/plugins/dnsproxy
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/dnsproxy --listen=0.0.0.0:$(v dpx_port 5353) \
	--upstream="$(v dpx_upstream https://dns.alidns.com/dns-query)" \
	>/tmp/dnsproxy.log 2>&1 &
echo $! > "$P"
