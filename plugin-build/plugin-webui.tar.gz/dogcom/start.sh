#!/bin/sh
# dogcom - started by the plugin center (pluginctl)
B=/etc/storage/plugins/dogcom
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
CFG=$B/dogcom.conf
[ -s "$CFG" ] || printf '%s\n' "$(v dogcom_cfg '')" > "$CFG"
BIN=$(ls /opt/bin 2>/dev/null | grep -i dogcom | head -1)
[ -n "$BIN" ] || exit 1
/opt/bin/$BIN $(v args '-m dhcp') -f "$CFG" >/tmp/dogcom.log 2>&1 &
echo $! > "$P"
