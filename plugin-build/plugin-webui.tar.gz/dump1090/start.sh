#!/bin/sh
# dump1090 - started by the plugin center (pluginctl)
B=/etc/storage/plugins/dump1090
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/dump1090 --net --net-http-port $(v adsb_http 8080) \
	--net-ro-port $(v adsb_raw 30002) $(v args '') >/tmp/dump1090.log 2>&1 &
echo $! > "$P"
