#!/bin/sh
# firefly - started by the plugin center (pluginctl)
B=/etc/storage/plugins/firefly
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
DIR=$(v ff_dir /media/AiDisk_a1)
BIN=$(ls /opt/bin 2>/dev/null | grep -i firefly | head -1)
[ -n "$BIN" ] || exit 1
/opt/bin/$BIN -f "$DIR" -p $(v ff_port 8090) $(v args '') >/tmp/firefly.log 2>&1 &
echo $! > "$P"
