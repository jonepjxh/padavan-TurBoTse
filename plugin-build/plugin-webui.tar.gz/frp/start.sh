#!/bin/sh
# frp - started by the plugin center (pluginctl)
B=/etc/storage/plugins/frp
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
INI=$B/frpc.ini
{
	echo "[common]"
	echo "server_addr = $(v frp_server "")"
	echo "server_port = $(v frp_port 7000)"
	TK=$(v frp_token "")
	[ -n "$TK" ] && echo "token = $TK"
	echo "[proxy1]"
	echo "type = $(v frp_type tcp)"
	echo "local_ip = $(v frp_local_ip 127.0.0.1)"
	echo "local_port = $(v frp_local_port 22)"
	echo "remote_port = $(v frp_remote_port 6022)"
} > "$INI"
/opt/bin/frpc -c "$INI" >/tmp/frpc.log 2>&1 &
echo $! > "$P"
