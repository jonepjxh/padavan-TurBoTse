#!/bin/sh
# gdut_drcom - started by the plugin center (pluginctl)
B=/etc/storage/plugins/gdut_drcom
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
BIN=$(ls /opt/bin 2>/dev/null | grep -i drcom | head -1)
[ -n "$BIN" ] || exit 1
/opt/bin/$BIN $(v args '') >/tmp/gdut.log 2>&1 &
echo $! > "$P"
