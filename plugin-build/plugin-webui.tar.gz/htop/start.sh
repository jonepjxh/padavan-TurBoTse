#!/bin/sh
# htop - build wrapper with saved options (plugin center hook)
B=/etc/storage/plugins/htop
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
d=$(v htop_delay); [ -n "$d" ] || d=1
opts="--delay=$d"
[ "$(v htop_tree)" = "1" ] && opts="$opts --tree"
mkdir -p "$B/bin"
cat > "$B/bin/htop" <<EOF2
#!/bin/sh
exec /usr/bin/htop $opts "\$@"
EOF2
chmod 0755 "$B/bin/htop"
echo "htop wrapper ready: $B/bin/htop $opts"
true
