#!/bin/sh
# inadyn - started by the plugin center (pluginctl)
B=/etc/storage/plugins/inadyn
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
USR="$(v ina_user "")"
ALI="$(v ina_alias "")"
if [ -z "$USR" ] || [ -z "$ALI" ]; then
	echo "inadyn: 请先在管理页填写用户名与域名" >&2
	killall inadyn 2>/dev/null
	exit 0
fi
/opt/sbin/inadyn --dyndns_system "$(v ina_system default@dyndns.org)" \
	--username "$USR" --password "$(v ina_pass "")" \
	--alias "$ALI" --update_period "$(v ina_period 300)" \
	--background --pidfile "$P" >/tmp/inadyn.log 2>&1
