#!/bin/sh
# iperf3 - started by the plugin center (pluginctl)
B=/etc/storage/plugins/iperf3
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/iperf3 -s -D -p $(v mode 5201) >/tmp/iperf3.log 2>&1
sleep 1
pidof iperf3 > "$P"
