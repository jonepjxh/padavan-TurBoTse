#!/bin/sh
# ipt2socks - started by the plugin center (pluginctl)
B=/etc/storage/plugins/ipt2socks
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/ipt2socks -s "$(v i2s_server "")" -p $(v i2s_server_port 8388) \
	-k "$(v i2s_pass "")" -m $(v i2s_method aes-256-gcm) \
	-l $(v i2s_local_port 1080) >/tmp/ipt2socks.log 2>&1 &
echo $! > "$P"
