#!/bin/sh
# lrzsz - build sz/rz wrappers (plugin center hook)
B=/etc/storage/plugins/lrzsz
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
d=$(v lrz_dir); [ -n "$d" ] || d=/etc/storage
mkdir -p "$B/bin"
n=0
for tool in sz lsz rz lrz; do
  [ -x "/usr/bin/$tool" ] || continue
cat > "$B/bin/$tool" <<EOF2
#!/bin/sh
cd "$d" 2>/dev/null || cd /tmp
exec /usr/bin/$tool "\$@"
EOF2
  chmod 0755 "$B/bin/$tool"
  n=$((n+1))
done
echo "lrzsz wrappers: $n tool(s) in $B/bin (dir=$d)"
true
