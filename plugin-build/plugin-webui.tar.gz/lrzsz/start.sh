#!/bin/sh
# lrzsz - build sz/rz wrappers (plugin center hook)
B=/etc/storage/plugins/lrzsz
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
d=$(v lrz_dir); [ -n "$d" ] || d=/etc/storage
mkdir -p "$B/bin"
for tool in sz rz; do
cat > "$B/bin/$tool" <<EOF2
#!/bin/sh
cd "$d" 2>/dev/null || cd /tmp
exec /usr/bin/$tool "\$@"
EOF2
chmod 0755 "$B/bin/$tool"
done
echo "lrzsz wrappers ready in $B/bin (dir=$d)"
true
