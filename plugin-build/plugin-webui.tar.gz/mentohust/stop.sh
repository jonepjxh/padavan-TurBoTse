#!/bin/sh
# mentohust - stopped by the plugin center (pluginctl)
B=/etc/storage/plugins/mentohust
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
killall mentohust 2>/dev/null
