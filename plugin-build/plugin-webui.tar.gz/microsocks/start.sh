#!/bin/sh
# microsocks - started by the plugin center (pluginctl)
B=/etc/storage/plugins/microsocks
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
U=$(v ms_user "")
AUTH=""
[ -n "$U" ] && AUTH="-u $U -P $(v ms_pass "")"
/opt/bin/microsocks -i $(v ms_bind 0.0.0.0) -p $(v ms_port 1080) $AUTH >/tmp/microsocks.log 2>&1 &
echo $! > "$P"
