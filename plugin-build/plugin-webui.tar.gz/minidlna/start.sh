#!/bin/sh
# minidlna - started by the plugin center (pluginctl)
B=/etc/storage/plugins/minidlna
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
DIR=$(v dlna_dir /media/AiDisk_a1)
CONF=$B/minidlna.conf
cat > "$CONF" <<EOF
port=$(v dlna_port 8200)
friendly_name=$(v dlna_name "Padavan DLNA")
media_dir=$DIR
db_dir=$B/db
log_dir=/tmp
inotify=yes
notify_interval=900
EOF
mkdir -p "$B/db" 2>/dev/null
/opt/bin/minidlna -f "$CONF" -R >/tmp/minidlna.log 2>&1 &
echo $! > "$P"
