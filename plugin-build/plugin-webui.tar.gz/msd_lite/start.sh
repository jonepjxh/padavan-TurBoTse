#!/bin/sh
# msd_lite - started by the plugin center (pluginctl)
B=/etc/storage/plugins/msd_lite
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
CFG=$B/msd_lite.xml
[ -s "$CFG" ] || printf '<msd><http><port>7088</port></http></msd>\n' > "$CFG"
/opt/bin/msd_lite -c "$CFG" >/tmp/msd_lite.log 2>&1 &
echo $! > "$P"
