#!/bin/sh
# mtr - started by the plugin center (pluginctl)
B=/etc/storage/plugins/mtr
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
[ -n "$(v args '')" ] && exit 0
exit 0
