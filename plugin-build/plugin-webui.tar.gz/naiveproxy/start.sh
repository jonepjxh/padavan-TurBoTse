#!/bin/sh
# naiveproxy - started by the plugin center (pluginctl)
B=/etc/storage/plugins/naiveproxy
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
PROXY=$(v naive_proxy "")
[ -n "$PROXY" ] || { echo "naive_proxy not set" > /tmp/naive.log; exit 1; }
EXTRA=""
[ "$(v naive_insecure 0)" = "1" ] && EXTRA="--insecure-concurrency=1"
/opt/bin/naive --listen=socks://0.0.0.0:$(v naive_port 1080) --proxy="$PROXY" $EXTRA >/tmp/naive.log 2>&1 &
echo $! > "$P"
