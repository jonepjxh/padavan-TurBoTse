#!/bin/sh
# nano - build wrapper with saved options (plugin center hook)
B=/etc/storage/plugins/nano
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
opts=""
[ "$(v nano_autoindent)" = "1" ] && opts="$opts -A"
[ "$(v nano_nowrap)" = "1" ] && opts="$opts -w"
[ "$(v nano_linenumbers)" = "1" ] && opts="$opts -l"
mkdir -p "$B/bin"
cat > "$B/bin/nano" <<EOF2
#!/bin/sh
exec /usr/bin/nano $opts "\$@"
EOF2
chmod 0755 "$B/bin/nano"
echo "nano wrapper ready: $B/bin/nano $opts"
true
