#!/bin/sh
# redsocks - started by the plugin center (pluginctl)
B=/etc/storage/plugins/redsocks
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
SS=$(v reds_ss 127.0.0.1:1080)
HOST=${SS%%:*}; PORT=${SS##*:}
cat > $B/redsocks.conf <<EOF
base {
 log_debug = off;
 log_info = off;
 daemon = on;
 redirector = iptables;
}
redsocks {
 local_ip = 0.0.0.0;
 local_port = $(v reds_port 12345);
 ip = $HOST;
 port = $PORT;
 type = $(v reds_type socks5);
}
EOF
cd "$B" || exit 1
/opt/bin/redsocks -c $B/redsocks.conf >/tmp/redsocks.log 2>&1
sleep 1
pidof redsocks > "$P"
