#!/bin/sh
# shadowsocks - started by the plugin center (pluginctl)
B=/etc/storage/plugins/shadowsocks
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
JSON=$B/ss.json
cat > "$JSON" <<EOF
{"server":"$(v ss_server "")","server_port":$(v ss_server_port 8388),"local_address":"0.0.0.0","local_port":$(v ss_local_port 1080),"password":"$(v ss_pass "")","method":"$(v ss_method aes-256-gcm)","timeout":600}
EOF
if [ "$(v ss_mode local)" = "redir" ]; then
	/opt/bin/ss-redir -c "$JSON" >/tmp/ss.log 2>&1 &
else
	/opt/bin/ss-local -c "$JSON" >/tmp/ss.log 2>&1 &
fi
echo $! > "$P"
