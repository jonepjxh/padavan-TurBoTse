#!/bin/sh
# singbox - started by the plugin center (pluginctl)
B=/etc/storage/plugins/singbox
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
CFG=$B/config.json
if [ ! -s "$CFG" ]; then
	cat > "$CFG" <<'EOF'
{"log":{"level":"warn"},"inbounds":[{"type":"mixed","listen":"::","listen_port":1080}],"outbounds":[{"type":"direct"}]}
EOF
fi
/opt/bin/sing-box run -c "$CFG" >/tmp/singbox.log 2>&1 &
echo $! > "$P"
