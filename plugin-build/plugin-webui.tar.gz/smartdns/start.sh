#!/bin/sh
# smartdns - started by the plugin center (pluginctl)
B=/etc/storage/plugins/smartdns
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
PORT=$(v sdns_port 6053)
CONF=/tmp/smartdns.conf
: > "$CONF"
echo "bind [::]:$PORT" >> "$CONF"
[ "$(v sdns_tcp 1)" = "1" ] && echo "bind-tcp [::]:$PORT" >> "$CONF"
echo "cache-size $(v sdns_cache 32768)" >> "$CONF"
echo "log-level $(v sdns_loglevel info)" >> "$CONF"
for s in $(v sdns_upstream "223.5.5.5 119.29.29.29"); do echo "server $s" >> "$CONF"; done
if [ "$(v sdns_adblock 0)" = "1" ] && [ -f "$B/adblock.conf" ]; then
	{ echo "conf-file $B/adblock.conf"; } >> "$CONF"
fi
/opt/bin/smartdns -c "$CONF" >/tmp/smartdns.log 2>&1 &
echo $! > "$P"
