#!/bin/sh
# socat - started by the plugin center (pluginctl)
B=/etc/storage/plugins/socat
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/socat TCP-LISTEN:$(v listen_port 8080),fork,reuseaddr TCP:"$(v target 192.168.1.100:80)" >/tmp/socat.log 2>&1 &
echo $! > "$P"
