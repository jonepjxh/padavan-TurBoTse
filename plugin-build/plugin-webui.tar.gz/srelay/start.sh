#!/bin/sh
# srelay - started by the plugin center (pluginctl)
B=/etc/storage/plugins/srelay
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/srelay -i $(v srelay_bind 0.0.0.0):$(v srelay_port 1080) >/tmp/srelay.log 2>&1 &
echo $! > "$P"
