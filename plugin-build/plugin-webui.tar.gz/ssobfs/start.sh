#!/bin/sh
# ssobfs - started by the plugin center (pluginctl)
B=/etc/storage/plugins/ssobfs
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/obfs-local -s "$(v obfs_server "")" -p $(v obfs_server_port 8388) \
	-l $(v obfs_local_port 1080) -k "$(v obfs_pass "")" \
	--obfs $(v obfs_obfs http) >/tmp/obfs.log 2>&1 &
echo $! > "$P"
