#!/bin/sh
# transmission - started by the plugin center (pluginctl)
B=/etc/storage/plugins/transmission
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
DIR=$(v tr_dir /media/AiDisk_a1/download)
mkdir -p "$DIR" "$B/work" 2>/dev/null
/opt/bin/transmission-daemon -g "$B/work" -w "$DIR" \
	-p $(v tr_port 9091) -a "*.*.*.*" \
	-u "$(v tr_user admin)" -v "$(v tr_pass "")" >/tmp/transmission.log 2>&1
sleep 2
pidof transmission-daemon > "$P"
