#!/bin/sh
# trojan - started by the plugin center (pluginctl)
B=/etc/storage/plugins/trojan
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
CFG=$B/config.json
[ -s "$CFG" ] || echo '{}' > "$CFG"
/opt/bin/trojan -c "$CFG" >/tmp/trojan.log 2>&1 &
echo $! > "$P"
