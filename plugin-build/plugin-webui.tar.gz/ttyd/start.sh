#!/bin/sh
# ttyd - started by the plugin center (pluginctl)
B=/etc/storage/plugins/ttyd
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
UP="$(v ttyd_user admin):$(v ttyd_pass "")"
/opt/bin/ttyd -p $(v ttyd_port 7681) -c "$UP" login >/tmp/ttyd.log 2>&1 &
echo $! > "$P"
