#!/bin/sh
# vlmcsd - started by the plugin center (pluginctl)
B=/etc/storage/plugins/vlmcsd
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
/opt/bin/vlmcsd -D -p $(v kms_port 1688) >/tmp/vlmcsd.log 2>&1
sleep 1
pidof vlmcsd > "$P"
