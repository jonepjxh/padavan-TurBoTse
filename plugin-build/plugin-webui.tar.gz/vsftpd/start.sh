#!/bin/sh
# vsftpd - started by the plugin center (pluginctl)
B=/etc/storage/plugins/vsftpd
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
DIR=$(v ftp_dir /media/AiDisk_a1)
CONF=$B/vsftpd.conf
cat > "$CONF" <<EOF
listen=YES
anonymous_enable=$( [ "$(v ftp_anon 1)" = "1" ] && echo YES || echo NO )
local_enable=YES
write_enable=YES
anon_root=$DIR
local_root=$DIR
listen_port=$(v ftp_port 21)
pasv_enable=YES
pasv_min_port=50000
pasv_max_port=50100
EOF
/opt/bin/vsftpd "$CONF" >/tmp/vsftpd.log 2>&1 &
echo $! > "$P"
