#!/bin/sh
# wireguard-go - started by the plugin center (pluginctl)
B=/etc/storage/plugins/wireguard-go
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
IF=$(v wg_if wg0)
CFGF=$(v wg_conf /etc/storage/plugins/wireguard-go/wg0.conf)
ADDR=$(v wg_addr 10.66.66.2/24)
[ -f "$CFGF" ] || { echo "wireguard: 缺少配置文件 $CFGF" >&2; exit 0; }
/opt/bin/wireguard "$IF" >/tmp/wireguard.log 2>&1 &
echo $! > "$P"
sleep 1
/opt/bin/wg setconf "$IF" "$CFGF" >>/tmp/wireguard.log 2>&1
[ -n "$ADDR" ] && ip addr add "$ADDR" dev "$IF" 2>/dev/null
ip link set "$IF" up 2>/dev/null
