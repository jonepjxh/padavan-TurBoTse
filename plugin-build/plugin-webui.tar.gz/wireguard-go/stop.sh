#!/bin/sh
# wireguard-go - stopped by the plugin center (pluginctl)
B=/etc/storage/plugins/wireguard-go
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
IF=$(v wg_if wg0)
ip link del "$IF" 2>/dev/null
killall wireguard 2>/dev/null
