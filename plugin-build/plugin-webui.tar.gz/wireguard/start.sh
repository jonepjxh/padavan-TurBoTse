#!/bin/sh
# wireguard - started by the plugin center (pluginctl)
B=/etc/storage/plugins/wireguard
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
IFACE=$(v wg_iface wg0)
[ -s "$B/$IFACE.conf" ] || printf '%s\n' "$(v wg_conf '')" > "$B/$IFACE.conf"
/opt/bin/wg show >/tmp/wg.log 2>&1
echo 0 > /dev/null
