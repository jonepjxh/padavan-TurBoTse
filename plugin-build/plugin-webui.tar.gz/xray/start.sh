#!/bin/sh
# xray - started by the plugin center (pluginctl)
B=/etc/storage/plugins/xray
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
CFG=$B/config.json
if [ ! -s "$CFG" ]; then
	cat > "$CFG" <<'EOF'
{"log":{"loglevel":"warning"},"inbounds":[{"port":1080,"protocol":"socks","settings":{"udp":true}}],"outbounds":[{"protocol":"freedom"}]}
EOF
fi
/opt/bin/xray -c "$CFG" >/tmp/xray.log 2>&1 &
echo $! > "$P"
