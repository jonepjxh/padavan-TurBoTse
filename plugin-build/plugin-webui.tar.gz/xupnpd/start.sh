#!/bin/sh
# xupnpd - started by the plugin center (pluginctl)
B=/etc/storage/plugins/xupnpd
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
DIR=$(v xupnpd_dir /media/AiDisk_a1)
cd "$B" || exit 1
[ -f "$B/xupnpd.lua" ] || printf 'HTTP_PORT = %s\n' "$(v xupnpd_port 4044)" > "$B/xupnpd.lua"
/opt/bin/xupnpd -d -c "$B/xupnpd.lua" >/tmp/xupnpd.log 2>&1 &
echo $! > "$P"
