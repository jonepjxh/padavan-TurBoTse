#!/bin/sh
# zerotier - started by the plugin center (pluginctl)
B=/etc/storage/plugins/zerotier
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
mkdir -p /var/lib/zerotier-one/networks.d
[ "$(v zero_nat 1)" = "1" ] && echo 1 > /var/lib/zerotier-one/allowTcpFallbackRelay 2>/dev/null
killall zerotier-one 2>/dev/null
sleep 1
/opt/bin/zerotier-one -d -p$(v zero_port 9993) >/tmp/zerotier.log 2>&1
sleep 3
NET=$(v zero_net "")
[ -n "$NET" ] && : > "/var/lib/zerotier-one/networks.d/$NET.local.conf"
pidof zerotier-one > "$P"
