#!/bin/sh
# zerotier - stopped by the plugin center (pluginctl)
B=/etc/storage/plugins/zerotier
C=$B/config
P=$B/run.pid
[ -f "$C" ] || : > "$C"
v() { awk -F'=' -v k="$1" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$C"; }
lstop() { [ -f "$P" ] && kill "$(cat "$P")" 2>/dev/null; sleep 1; rm -f "$P"; }
lstop
NET=$(v zero_net "")
[ -n "$NET" ] && rm -f "/var/lib/zerotier-one/networks.d/$NET.local.conf"
killall zerotier-one 2>/dev/null
