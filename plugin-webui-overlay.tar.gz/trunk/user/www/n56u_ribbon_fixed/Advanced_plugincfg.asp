<!DOCTYPE html>
<html>
<head>
<title><#Web_Title#> - <#menu5_41#></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/main.css">
<script type="text/javascript" src="/jquery.js"></script>
<script type="text/javascript" src="/state.js"></script>
<script type="text/javascript" src="/general.js"></script>
<script type="text/javascript" src="/popup.js"></script>
<script>
<% login_state_hook(); %>

// Injected by the plugin_webui C hook:
// [{n:"wireguard",t:"WireGuard",f:[[key,label,type,default,current],...]}, ...]
var plugcfg = <% plugin_webui(); %>;
var cur = 0;

function initial(){
    show_banner(1);
    show_menu(5,7,8);
    show_footer();
    renderTabs();
    renderForm();
}

function esc(s){ s=String(s==null?'':s); return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

function renderTabs(){
    var box=document.getElementById('tabs');
    if(!plugcfg.length){ box.innerHTML='<div class="alert">没有带设置界面的插件。请先到「插件中心」安装支持设置的插件（包内带 webui.conf）。</div>'; return; }
    var h='<ul class="nav nav-tabs">';
    for(var i=0;i<plugcfg.length;i++){
        h+='<li'+(i===cur?' class="active"':'')+'><a href="javascript:void(0)" onclick="selTab('+i+')">'+esc(plugcfg[i].t)+'</a></li>';
    }
    h+='</ul>';
    box.innerHTML=h;
}

function selTab(i){ cur=i; renderTabs(); renderForm(); }

function renderForm(){
    var box=document.getElementById('formbox');
    if(!plugcfg.length){ box.innerHTML=''; return; }
    var p=plugcfg[cur];
    var h='<div class="well" style="background:#fff;">';
    h+='<h3 style="margin-top:0;">'+esc(p.t)+' <small>'+esc(p.n)+'</small></h3>';
    h+='<form name="cfgform" id="cfgform" class="form-horizontal">';
    for(var i=0;i<p.f.length;i++){
        var f=p.f[i], key=f[0], label=f[1], type=f[2], def=f[3], val=f[4];
        h+='<div class="control-group"><label class="control-label">'+esc(label)+'</label><div class="controls">';
        if(type==='radio'){
            h+='<label class="radio inline"><input type="radio" name="c_'+i+'" value="1" '+((val==='1')?'checked':'')+'> 是</label>';
            h+='<label class="radio inline"><input type="radio" name="c_'+i+'" value="0" '+((val!=='1')?'checked':'')+'> 否</label>';
        }else if(type==='password'){
            h+='<input type="password" id="c_'+i+'" value="'+esc(val)+'" style="width:420px;">';
        }else if(type.indexOf('select')===0){
            var opts=type.substring(7).split(',');
            h+='<select id="c_'+i+'">';
            for(var j=0;j<opts.length;j++){
                var ov=opts[j].split('=',2); var ok=ov[0], ot=(ov.length>1?ov[1]:ov[0]);
                h+='<option value="'+esc(ok)+'" '+((val===ok)?'selected':'')+'>'+esc(ot)+'</option>';
            }
            h+='</select>';
        }else{
            h+='<input type="text" id="c_'+i+'" value="'+esc(val)+'" style="width:420px;">';
        }
        h+='</div></div>';
    }
    h+='<div class="control-group"><div class="controls">';
    h+='<button type="button" class="btn btn-primary" onclick="doApply()">应用设置</button> ';
    h+='<button type="button" class="btn" onclick="refreshpage()">取消</button>';
    h+='</div></div></form></div>';
    box.innerHTML=h;
}

function doApply(){
    var p=plugcfg[cur];
    var parts=[], i, f, v;
    for(i=0;i<p.f.length;i++){
        f=p.f[i];
        if(f[2]==='radio'){
            v = document.querySelector('input[name="c_'+i+'"]:checked');
            v = v ? v.value : '0';
        }else{
            v = document.getElementById('c_'+i).value;
        }
        v = String(v).replace(/'/g,"'\\''");   // shell single-quote safe
        parts.push("'"+f[0]+"="+v+"'");
    }
    var name = String(p.n).replace(/'/g,"'\\''");
    document.form.action_mode.value = " SystemCmd ";
    document.form.SystemCmd.value = "/usr/bin/pluginctl setcfg '"+name+"' "+parts.join(" ")+" >/dev/null 2>&1";
    document.form.current_page.value = "/Advanced_plugincfg.asp";
    document.form.next_page.value = "/Advanced_plugincfg.asp";
    document.form.submit();
}
function done_validating(action){ refreshpage(); }
</script>
</head>
<body onload="initial();" onunLoad="return unload_body();">
<div class="wrapper">
<div class="container-fluid" style="padding-right:0px">
<div class="row-fluid"><div class="span3"><center><div id="logo"></div></center></div><div class="span9"><div id="TopBanner"></div></div></div>
</div>
<div id="Loading" class="popup_bg"></div>
<iframe name="hidden_frame" id="hidden_frame" src="" width="0" height="0" frameborder="0"></iframe>
<form method="post" name="form" id="ruleForm" action="/start_apply.htm" target="hidden_frame">
<input type="hidden" name="current_page" value="Advanced_plugincfg.asp">
<input type="hidden" name="next_page" value="">
<input type="hidden" name="next_host" value="">
<input type="hidden" name="sid_list" value="General;">
<input type="hidden" name="group_id" value="">
<input type="hidden" name="action_mode" value="">
<input type="hidden" name="action_script" value="">
<input type="hidden" name="SystemCmd" value="">

<div class="container-fluid">
<div class="row-fluid"><div class="span12">
<div id="tabs"></div>
<div id="formbox" style="margin-top:14px;"></div>
</div></div>
</div>
</form>
</div>
</body>
</html>
