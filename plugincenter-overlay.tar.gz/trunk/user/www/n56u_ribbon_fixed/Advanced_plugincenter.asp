<!DOCTYPE html>
<html>
<head>
<title><#Web_Title#> - <#menu5_40#></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="icon" href="images/favicon.png">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/bootstrap/css/main.css">
<script type="text/javascript" src="/jquery.js"></script>
<script type="text/javascript" src="/state.js"></script>
<script type="text/javascript" src="/general.js"></script>
<script type="text/javascript" src="/popup.js"></script>
<script>
<% login_state_hook(); %>

var plugins = [];
// data injected by the plugin_center ASP hook: array of "name|title|file|size|installed|enabled"
// 延迟到 body 内 nvram_dump 之后注入，保证「同步/操作」后拿到的是执行完的最新列表
var raw = [];

function initial(){
    /* 本页未定义 mainMenu/subMenu/tabMenu/footer 容器，show_menu()/show_footer() 会对 null
       赋 innerHTML 抛异常，旧顺序会连带跳过 parseData()/render()，导致表格 0 行。
       故先渲染数据，界面框架调用全部容错。 */
    parseData();
    render();
    try { show_banner(1); } catch(e) {}
    try { show_menu(5,10,4); } catch(e) {}
    try { show_footer(); } catch(e) {}
}

function parseData(){
    plugins = [];
    for (var i=0;i<raw.length;i++){
        var p = raw[i].split('|');
        if(p.length < 6) continue;
        plugins.push({name:p[0],title:p[1],file:p[2],size:p[3],installed:p[4]==='1',enabled:p[5]==='1'});
    }
}

function fmtSize(n){ n=parseInt(n)||0; return n>1048576?(n/1048576).toFixed(1)+' MB':(n/1024).toFixed(0)+' KB'; }

function render(){
    var box = document.getElementById('pluginList');
    if(!plugins.length){
        box.innerHTML = '<div class="alert">插件列表为空。请先点击「同步仓库」从 GitHub 拉取插件清单。</div>';
        return;
    }
    var h = '<table class="table table-striped table-bordered" style="background:#fff;">';
    h += '<thead><tr><th>插件</th><th>文件</th><th>大小</th><th>状态</th><th style="width:260px;">操作</th></tr></thead><tbody>';
    for(var i=0;i<plugins.length;i++){
        var p=plugins[i];
        var state = p.installed ? (p.enabled ? '<span style="color:#3a8;font-weight:bold;">已安装 · 已启用</span>' : '<span style="color:#c60;">已安装 · 未启用</span>') : '<span style="color:#999;">未安装</span>';
        var ops='';
        if(!p.installed){
            ops='<button class="btn btn-small btn-primary" onclick="doCmd(\'install '+p.name+'\')">安装</button>';
        }else{
            ops='<button class="btn btn-small" onclick="doCmd(\'start '+p.name+'\')">启用/启动</button> '
              +'<button class="btn btn-small" onclick="doCmd(\'disable '+p.name+'\')">禁用自启</button> '
              +'<button class="btn btn-small btn-danger" onclick="doCmd(\'remove '+p.name+'\')">卸载</button>';
        }
        h+='<tr><td><b>'+p.title+'</b><br><small>'+p.name+'</small></td><td><small>'+p.file+'</small></td><td>'+fmtSize(p.size)+'</td><td>'+state+'</td><td>'+ops+'</td></tr>';
    }
    h+='</tbody></table>';
    box.innerHTML=h;
}

function doCmd(cmd){
    if(cmd.indexOf('remove')===0 && !confirm('确定卸载该插件？')) return;
    try { showLoading(); } catch(e) {}
    postSystemCmd("/usr/bin/pluginctl " + cmd + " >/dev/null 2>&1; /usr/bin/pluginctl list >/dev/null 2>&1");
}
function doSync(){
    try { showLoading(); } catch(e) {}
    postSystemCmd("/usr/bin/pluginctl sync >/dev/null 2>&1");
}

/* 命令必须提交到 /apply.cgi（apply_cgi 的 action_mode==" SystemCmd " 分支），
   再由本页 body 里的 nvram_dump("syscmd.log","syscmd.sh") 钩子触发执行。 */
function postSystemCmd(syscmd){
    var body = 'action_mode=' + encodeURIComponent(' SystemCmd ')
             + '&SystemCmd=' + encodeURIComponent(syscmd)
             + '&sid_list=' + encodeURIComponent('General.')
             + '&current_page=' + encodeURIComponent('/Advanced_plugincenter.asp')
             + '&next_page=' + encodeURIComponent('/Advanced_plugincenter.asp');
    var x = new XMLHttpRequest();
    x.open('POST', '/apply.cgi', true);
    x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    x.onreadystatechange = function(){
        if (x.readyState !== 4) return;
        // 服务器返回 302 后本机再次渲染本页，此时 syscmd.sh 已执行完毕，刷新取新列表
        location.href = '/Advanced_plugincenter.asp?' + (new Date()).getTime();
    };
    x.send(body);
}
function done_validating(action){ refreshpage(); }
</script>
</head>

<body onload="initial();" onunLoad="return unload_body();">
<!-- 命令执行钩子：页面渲染时 syscmd.sh 会执行 /apply.cgi 存入的 SystemCmd，随后再取插件列表 -->
<textarea id="syscmd_log" style="display:none" readonly><% nvram_dump("syscmd.log","syscmd.sh"); %></textarea>
<script type="text/javascript">raw = <% plugin_center(); %>;</script>
<div class="wrapper">
<div class="container-fluid" style="padding-right:0px">
<div class="row-fluid"><div class="span3"><center><div id="logo"></div></center></div><div class="span9"><div id="TopBanner"></div></div></div>
</div>
<div id="Loading" class="popup_bg"></div>
<iframe name="hidden_frame" id="hidden_frame" src="" width="0" height="0" frameborder="0"></iframe>
<form method="post" name="form" id="ruleForm" action="/apply.cgi" target="hidden_frame">
<input type="hidden" name="current_page" value="Advanced_plugincenter.asp">
<input type="hidden" name="next_page" value="">
<input type="hidden" name="next_host" value="">
<input type="hidden" name="sid_list" value="General;">
<input type="hidden" name="group_id" value="">
<input type="hidden" name="action_mode" value="">
<input type="hidden" name="action_script" value="">
<input type="hidden" name="SystemCmd" value="">

<div class="container-fluid">
<div class="row-fluid"><div class="span12">
<div class="well" style="background:#fff;">
<h3 style="margin-top:0;"><#menu5_40#> <small>插件中心 · 在线下载与安装</small></h3>
<p style="color:#666;">插件包来自 <code>jonepjxh/padavan-TurBoTse</code> 的插件仓库，安装到路由器持久化存储 <code>/etc/storage/plugins/</code>，重启不丢失。首次使用请先「同步仓库」。</p>
<div style="margin-bottom:14px;">
<button class="btn btn-success" onclick="doSync()">同步仓库</button>
<button class="btn" onclick="location.href='/Advanced_plugincenter.asp?'+(new Date()).getTime()">刷新列表</button>
</div>
<div id="pluginList"></div>
</div>
</div></div>
</div>
</form>
</div>
</body>
</html>
